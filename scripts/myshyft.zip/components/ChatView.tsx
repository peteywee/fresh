import React, { useState, useRef, useEffect } from 'react';
import type { User, Conversation, Message } from '../types';
import { SendIcon } from './icons';

interface ChatViewProps {
  users: User[];
  currentUser: User;
  conversation: Conversation;
  messages: Message[];
  onSendMessage: (conversationId: string, text: string) => void;
}

const ChatView: React.FC<ChatViewProps> = ({ users, currentUser, conversation, messages, onSendMessage }) => {
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const otherParticipantId = conversation.participants.find(p => p !== currentUser.uid);
  const otherUser = users.find(u => u.uid === otherParticipantId);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSendMessage(conversation.id, newMessage);
    setNewMessage('');
  };

  const formatTimestamp = (timestamp: Message['timestamp']) => {
    if (!timestamp) return '';
    return new Date(timestamp.seconds * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  if (!otherUser) {
    return <div className="flex-1 flex items-center justify-center"><p>Loading participant...</p></div>;
  }

  return (
    <div className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900 h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 flex items-center space-x-3">
        <img className="h-10 w-10 rounded-full object-cover" src={otherUser.photoURL} alt={otherUser.displayName} />
        <div>
          <h2 className="text-lg font-bold text-gray-800 dark:text-white">{otherUser.displayName}</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">Role: {otherUser.role}</p>
        </div>
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((msg, index) => {
          const isCurrentUser = msg.senderId === currentUser.uid;
          const sender = isCurrentUser ? currentUser : users.find(u => u.uid === msg.senderId);
          const showAvatar = index === 0 || messages[index - 1].senderId !== msg.senderId;

          return (
            <div key={msg.id} className={`flex items-end gap-3 ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
              {!isCurrentUser && (
                 <div className="w-8 h-8 flex-shrink-0">
                  {showAvatar && <img src={sender?.photoURL} alt={sender?.displayName} className="w-full h-full rounded-full object-cover" />}
                 </div>
              )}
              <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl ${isCurrentUser ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-bl-none'}`}>
                <p className="text-sm">{msg.text}</p>
                <p className={`text-xs mt-1 ${isCurrentUser ? 'text-indigo-200' : 'text-gray-400 dark:text-gray-500'} text-right`}>
                  {formatTimestamp(msg.timestamp)}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
        <form onSubmit={handleSubmit} className="flex items-center space-x-3">
          <input
            type="text"
            value={newMessage}
            onChange={e => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            autoComplete="off"
            className="w-full px-4 py-2 text-gray-700 bg-gray-100 dark:bg-gray-700 dark:text-gray-200 border border-transparent rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="p-3 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed flex items-center justify-center transition-colors duration-200 flex-shrink-0"
            aria-label="Send Message"
          >
            <SendIcon className="w-5 h-5"/>
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatView;