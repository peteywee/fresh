
import React, { useState, useCallback } from 'react';
import { askAiAssistant } from '../services/geminiService';
import { SparklesIcon, SendIcon, CalendarPlusIcon } from './icons';
import Calendar from './Calendar';
import ShiftModal from './ShiftModal';
import GenerateScheduleModal from './GenerateScheduleModal';
import type { Shift, User } from '../types';

const AiAssistant = () => {
    const [prompt, setPrompt] = useState('');
    const [response, setResponse] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim() || isLoading) return;

        setIsLoading(true);
        setError('');
        setResponse('');
        try {
            const result = await askAiAssistant(prompt);
            setResponse(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [prompt, isLoading]);

    return (
        <div className="mt-8 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                <SparklesIcon className="w-6 h-6 mr-2 text-indigo-500" />
                AI Management Assistant
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
                Ask for tips on shift scheduling, team management, or conflict resolution.
            </p>
            <form onSubmit={handleSubmit}>
                <div className="flex items-center space-x-2">
                    <input
                        type="text"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="e.g., How can I improve team morale?"
                        className="w-full px-4 py-2 text-gray-700 bg-gray-100 dark:bg-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !prompt.trim()}
                        className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed flex items-center justify-center transition-colors duration-200"
                    >
                        {isLoading ? (
                           <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        ) : (
                           <SendIcon className="w-5 h-5"/>
                        )}
                    </button>
                </div>
            </form>
            
            {error && <div className="mt-4 text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
            
            {response && (
                <div className="mt-4 p-4 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg">
                    <p className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap">{response}</p>
                </div>
            )}
        </div>
    );
};

interface DashboardProps {
    shifts: Shift[];
    users: User[];
    onAddShift: (newShift: Omit<Shift, 'id'>) => void;
    onUpdateShift: (shift: Shift) => void;
    onDeleteShift: (shiftId: string) => void;
    currentUser: User;
}

const Dashboard: React.FC<DashboardProps> = ({ shifts, users, onAddShift, onUpdateShift, onDeleteShift, currentUser }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [shiftToEdit, setShiftToEdit] = useState<Shift | null>(null);
  const [isGenerateModalOpen, setGenerateModalOpen] = useState(false);

  const handleAddShiftClick = (date: string) => {
    setShiftToEdit(null);
    setSelectedDate(date);
    setIsModalOpen(true);
  };
  
  const handleEditShiftClick = (shift: Shift) => {
    setShiftToEdit(shift);
    setSelectedDate(shift.date);
    setIsModalOpen(true);
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setSelectedDate(null);
    setShiftToEdit(null);
  };
  
  const handleModalSave = (shiftData: Omit<Shift, 'id'> | Shift) => {
    if ('id' in shiftData) {
        onUpdateShift(shiftData);
    } else {
        onAddShift(shiftData);
    }
    handleModalClose();
  };
  
  const handleBulkAddShifts = (newShifts: Omit<Shift, 'id' | 'orgId'>[]) => {
      newShifts.forEach(shift => {
          onAddShift({ ...shift, orgId: currentUser.orgId });
      });
  };

  return (
    <div>
      <div className="flex flex-wrap justify-between items-center gap-4">
        <div>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Dashboard</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">Welcome back, {currentUser.displayName}! Here's what's happening.</p>
        </div>
        {currentUser.role === 'management' && (
            <button
                onClick={() => setGenerateModalOpen(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"
            >
                <CalendarPlusIcon className="w-5 h-5" />
                <span>Generate Schedule</span>
            </button>
        )}
      </div>
      
      <Calendar 
        shifts={shifts}
        users={users}
        onAddShiftClick={handleAddShiftClick}
        onEditShiftClick={handleEditShiftClick}
        onDeleteShift={onDeleteShift}
        userRole={currentUser.role}
      />
      
      {isModalOpen && selectedDate && (
        <ShiftModal
          isOpen={isModalOpen}
          onClose={handleModalClose}
          onSave={handleModalSave}
          users={users.filter(u => u.role === 'staff')}
          date={selectedDate}
          shiftToEdit={shiftToEdit}
          orgId={currentUser.orgId}
        />
      )}
      
      {isGenerateModalOpen && (
        <GenerateScheduleModal
            isOpen={isGenerateModalOpen}
            onClose={() => setGenerateModalOpen(false)}
            onScheduleGenerated={handleBulkAddShifts}
            users={users.filter(u => u.role === 'staff')}
        />
      )}

      <AiAssistant />
    </div>
  );
};

export default Dashboard;
