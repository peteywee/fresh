
import React, { useState } from 'react';
import { LogoIcon, GoogleIcon } from './icons';
import * as firebaseService from '../services/firebaseService';

const Login: React.FC = () => {
    const [isSigningIn, setIsSigningIn] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSignIn = async () => {
        setIsSigningIn(true);
        setError(null);
        try {
            await firebaseService.signInWithGoogle();
        } catch (err) {
            setError("Failed to sign in. Please try again.");
            console.error(err);
            setIsSigningIn(false);
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
            <div className="w-full max-w-sm mx-auto">
                <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 text-center">
                    <div className="flex items-center justify-center mb-6">
                        <LogoIcon className="h-12 w-12 text-indigo-500" />
                        <span className="text-4xl font-bold text-gray-800 dark:text-white ml-3">Shyft</span>
                    </div>
                    <h1 className="text-2xl font-semibold text-gray-700 dark:text-gray-200">
                        Welcome Back
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 mt-2 mb-8">
                        Sign in to manage your staff and shifts.
                    </p>
                    
                    {error && <p className="mb-4 text-sm text-red-500">{error}</p>}

                    <button
                        onClick={handleSignIn}
                        disabled={isSigningIn}
                        className="w-full inline-flex items-center justify-center px-4 py-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-wait transition-colors"
                    >
                        {isSigningIn ? (
                            <>
                               <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-gray-900 dark:border-white mr-3"></div>
                               Signing in...
                            </>
                        ) : (
                            <>
                                <GoogleIcon className="w-5 h-5 mr-3" />
                                Sign in with Google
                            </>
                        )}
                    </button>
                    <p className="mt-6 text-xs text-gray-400 dark:text-gray-500">
                        By signing in, you agree to our terms of service.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Login;