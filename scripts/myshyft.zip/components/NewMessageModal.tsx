import React from 'react';
import type { User } from '../types';
import { CloseIcon } from './icons';

interface NewMessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
  onStartConversation: (userId: string) => void;
}

const NewMessageModal: React.FC<NewMessageModalProps> = ({ isOpen, onClose, users, onStartConversation }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog" onClick={onClose}>
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md transform transition-all" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
          <h3 className="text-xl font-semibold text-gray-800 dark:text-white">Start New Conversation</h3>
          <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close modal">
            <CloseIcon className="w-5 h-5 text-gray-500 dark:text-gray-400"/>
          </button>
        </div>
        <div className="p-2 max-h-96 overflow-y-auto">
            <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                {users.map(user => (
                    <li key={user.uid}>
                        <button 
                            onClick={() => onStartConversation(user.uid)}
                            className="w-full flex items-center p-3 space-x-4 text-left hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors"
                        >
                            <img src={user.photoURL} alt={user.displayName} className="w-10 h-10 rounded-full object-cover" />
                            <div className="flex-1">
                                <p className="font-semibold text-gray-800 dark:text-gray-200">{user.displayName}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400 capitalize">{user.role}</p>
                            </div>
                        </button>
                    </li>
                ))}
            </ul>
        </div>
      </div>
    </div>
  );
};

export default NewMessageModal;