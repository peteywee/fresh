
import React from 'react';
import type { PayHistoryEntry, User } from '../types';

interface PayHistoryProps {
    payHistory: PayHistoryEntry[];
    users: User[];
}

const PayHistory: React.FC<PayHistoryProps> = ({ payHistory, users }) => {
    
    const getUserDisplayName = (userId: string) => {
        return users.find(u => u.uid === userId)?.displayName || 'Unknown User';
    };

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Pay History</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">Review past payment records.</p>
            
            <div className="mt-8 bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                        <tr>
                            <th className="p-4 font-semibold text-sm text-gray-600 dark:text-gray-300 whitespace-nowrap">Staff Member</th>
                            <th className="p-4 font-semibold text-sm text-gray-600 dark:text-gray-300 whitespace-nowrap">Pay Period</th>
                            <th className="p-4 font-semibold text-sm text-gray-600 dark:text-gray-300 whitespace-nowrap text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                        {payHistory.length > 0 ? payHistory.map(entry => (
                            <tr key={entry.id}>
                                <td className="p-4 whitespace-nowrap">
                                    <div className="text-gray-800 dark:text-gray-200">{getUserDisplayName(entry.userId)}</div>
                                </td>
                                <td className="p-4 whitespace-nowrap text-gray-600 dark:text-gray-400">{entry.periodStart} to {entry.periodEnd}</td>
                                <td className="p-4 whitespace-nowrap text-gray-800 dark:text-gray-200 text-right font-medium">{new Intl.NumberFormat('en-US', { style: 'currency', currency: entry.currency }).format(entry.amount)}</td>
                            </tr>
                        )) : (
                            <tr>
                                <td colSpan={3} className="p-8 text-center text-gray-500 dark:text-gray-400">No pay history found.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default PayHistory;
