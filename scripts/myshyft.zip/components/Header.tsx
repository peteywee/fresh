
import React, { useState, useRef, useEffect } from 'react';
import { Theme, type Environment, type User } from '../types';
import { ENVIRONMENTS } from '../constants';
import { MoonIcon, SunIcon, SystemIcon, ChevronDownIcon, MenuIcon } from './icons';

interface HeaderProps {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  environment: Environment;
  setEnvironment: (env: Environment) => void;
  user: User;
  onMenuClick: () => void;
  onSignOut?: () => void;
}

const Header: React.FC<HeaderProps> = ({ theme, setTheme, environment, setEnvironment, user, onMenuClick, onSignOut }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const currentEnv = ENVIRONMENTS.find(e => e.value === environment);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [dropdownRef]);

  const handleSignOut = (e: React.MouseEvent) => {
    e.preventDefault();
    if(onSignOut) {
        onSignOut();
    }
  };

  return (
    <header className="flex justify-between items-center h-20 px-6 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
      <div className="flex items-center">
        <button onClick={onMenuClick} className="md:hidden mr-4 text-gray-600 dark:text-gray-400">
           <MenuIcon className="h-6 w-6" />
        </button>
        <div className={`${currentEnv?.color} text-white text-xs font-bold px-2 py-1 rounded-full hidden sm:block`}>
            {currentEnv?.label}
        </div>
      </div>
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-1 rounded-md bg-gray-200 dark:bg-gray-700 p-1">
          <button onClick={() => setTheme(Theme.Light)} className={`p-1.5 rounded-md ${theme === Theme.Light ? 'bg-white dark:bg-gray-600' : ''}`} aria-label="Set light theme"><SunIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" /></button>
          <button onClick={() => setTheme(Theme.Dark)} className={`p-1.5 rounded-md ${theme === Theme.Dark ? 'bg-white dark:bg-gray-600' : ''}`} aria-label="Set dark theme"><MoonIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" /></button>
          <button onClick={() => setTheme(Theme.System)} className={`p-1.5 rounded-md ${theme === Theme.System ? 'bg-white dark:bg-gray-600' : ''}`} aria-label="Set system theme"><SystemIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" /></button>
        </div>

        <div className="relative" ref={dropdownRef}>
          <button onClick={() => setDropdownOpen(!dropdownOpen)} className="flex items-center space-x-2">
            <img className="h-10 w-10 rounded-full object-cover" src={user.photoURL} alt="User avatar" />
            <div className="text-left hidden md:block">
              <p className="font-semibold text-sm text-gray-800 dark:text-white">{user.displayName}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{user.role}</p>
            </div>
            <ChevronDownIcon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>
          {dropdownOpen && (
            <div className="absolute right-0 mt-2 py-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-xl z-20 border border-gray-200 dark:border-gray-700">
              <div className="px-4 py-2 border-b dark:border-gray-700">
                  <p className="font-bold text-sm text-gray-800 dark:text-white">{user.displayName}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{user.email}</p>
              </div>
              <p className="px-4 pt-2 text-xs text-gray-500 dark:text-gray-400">Switch Environment</p>
              {ENVIRONMENTS.map(env => (
                <a
                  key={env.value}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setEnvironment(env.value);
                    setDropdownOpen(false);
                  }}
                  className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <span className={`inline-block w-3 h-3 mr-2 rounded-full ${env.color}`}></span>
                  {env.label}
                </a>
              ))}
              <a
                href="#"
                onClick={handleSignOut}
                className={`block w-full text-left px-4 py-2 mt-2 border-t dark:border-gray-700 text-sm ${onSignOut ? 'text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700' : 'text-gray-400 dark:text-gray-500 cursor-not-allowed'}`}
                aria-disabled={!onSignOut}
              >
                Log out
              </a>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;