import React, { useState, useRef, useEffect } from 'react';
import type { User } from '../types';
import { UploadIcon } from './icons';

interface SettingsProps {
    user: User;
    onProfileUpdate: (data: { displayName?: string; photoFile?: File }) => Promise<void>;
    onInvite: (email: string, role: 'management' | 'staff') => Promise<void>;
}

const UserProfileSection: React.FC<Pick<SettingsProps, 'user' | 'onProfileUpdate'>> = ({ user, onProfileUpdate }) => {
    const [displayName, setDisplayName] = useState(user.displayName);
    const [photoFile, setPhotoFile] = useState<File | null>(null);
    const [photoPreview, setPhotoPreview] = useState<string | null>(user.photoURL);
    const [isLoading, setIsLoading] = useState(false);
    const [feedback, setFeedback] = useState<{ type: 'success' | 'error', message: string } | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        // Revoke the object URL to avoid memory leaks
        return () => {
            if (photoPreview && photoPreview.startsWith('blob:')) {
                URL.revokeObjectURL(photoPreview);
            }
        };
    }, [photoPreview]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setPhotoFile(file);
            setPhotoPreview(URL.createObjectURL(file));
            setFeedback(null);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!displayName.trim()) {
            setFeedback({ type: 'error', message: 'Display name cannot be empty.'});
            return;
        }

        setIsLoading(true);
        setFeedback(null);
        try {
            await onProfileUpdate({
                displayName: displayName !== user.displayName ? displayName : undefined,
                photoFile: photoFile || undefined,
            });
            setFeedback({ type: 'success', message: 'Profile updated successfully!' });
            setPhotoFile(null); // Clear file after successful upload
        } catch (error) {
            const message = error instanceof Error ? error.message : "An unknown error occurred.";
            setFeedback({ type: 'error', message: `Update failed: ${message}`});
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 p-6 sm:p-8 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 space-y-6">
            <h2 className="text-xl font-bold text-gray-800 dark:text-white">User Profile</h2>
            
            <div className="flex items-center space-x-6">
                <img
                    src={photoPreview || `https://i.pravatar.cc/150?u=${user.uid}`}
                    alt="Profile Preview"
                    className="h-24 w-24 rounded-full object-cover ring-4 ring-indigo-200 dark:ring-indigo-800"
                />
                <div>
                    <input type="file" accept="image/png, image/jpeg" onChange={handleFileChange} ref={fileInputRef} className="hidden" />
                    <button type="button" onClick={() => fileInputRef.current?.click()} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none">
                        <UploadIcon className="w-5 h-5 inline-block mr-2" />
                        Change Picture
                    </button>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">JPG or PNG. 1MB max.</p>
                </div>
            </div>

            <div>
                <label htmlFor="displayName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Display Name</label>
                <input
                    type="text"
                    id="displayName"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500"
                />
            </div>
            <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                <input type="email" id="email" value={user.email} readOnly disabled className="mt-1 block w-full px-3 py-2 bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-gray-500 dark:text-gray-400" />
            </div>

            {feedback && (
                <div className={`p-3 rounded-md text-sm ${feedback.type === 'success' ? 'bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-300' : 'bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-300'}`}>
                    {feedback.message}
                </div>
            )}
            
            <div className="flex justify-end">
                <button type="submit" disabled={isLoading} className="px-6 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed flex items-center">
                    {isLoading && <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>}
                    {isLoading ? 'Saving...' : 'Save Changes'}
                </button>
            </div>
        </form>
    );
};

const InviteSection: React.FC<{ onInvite: SettingsProps['onInvite'] }> = ({ onInvite }) => {
    const [email, setEmail] = useState('');
    const [role, setRole] = useState<'staff' | 'management'>('staff');
    const [isLoading, setIsLoading] = useState(false);
    const [feedback, setFeedback] = useState<{ type: 'success' | 'error', message: string } | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setFeedback(null);
        if (!email.trim() || !/^\S+@\S+\.\S+$/.test(email)) {
            setFeedback({ type: 'error', message: 'Please enter a valid email address.'});
            return;
        }

        setIsLoading(true);
        try {
            await onInvite(email, role);
            setFeedback({ type: 'success', message: `Invitation sent to ${email}!` });
            setEmail('');
        } catch (error) {
            const message = error instanceof Error ? error.message : "An unknown error occurred.";
            setFeedback({ type: 'error', message: `Failed to send invitation: ${message}` });
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 p-6 sm:p-8 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 space-y-6">
            <h2 className="text-xl font-bold text-gray-800 dark:text-white">Invite Team Members</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">Invite new users to your organization. They will receive an email prompting them to sign in.</p>
            
            <div className="flex flex-col sm:flex-row sm:items-end sm:space-x-4 space-y-4 sm:space-y-0">
                <div className="flex-grow">
                    <label htmlFor="invite-email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                    <input type="email" id="invite-email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="new.employee@example.com" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500"/>
                </div>
                <div>
                     <label htmlFor="invite-role" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Role</label>
                    <select id="invite-role" value={role} onChange={e => setRole(e.target.value as 'staff' | 'management')} className="mt-1 block w-full pl-3 pr-10 py-2 border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 rounded-md">
                        <option value="staff">Staff</option>
                        <option value="management">Management</option>
                    </select>
                </div>
                <button type="submit" disabled={isLoading} className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed flex items-center justify-center">
                    {isLoading && <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>}
                    Send Invite
                </button>
            </div>
             {feedback && (
                <div className={`p-3 rounded-md text-sm ${feedback.type === 'success' ? 'bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-300' : 'bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-300'}`}>
                    {feedback.message}
                </div>
            )}
        </form>
    );
};


const Settings: React.FC<SettingsProps> = ({ user, onProfileUpdate, onInvite }) => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Settings</h1>
      <p className="mt-2 text-gray-600 dark:text-gray-400">Manage your profile, preferences, and organization.</p>
      
      <div className="mt-8 max-w-2xl mx-auto space-y-8">
        <UserProfileSection user={user} onProfileUpdate={onProfileUpdate} />
        {user.role === 'management' && <InviteSection onInvite={onInvite} />}
      </div>
    </div>
  );
};

export default Settings;