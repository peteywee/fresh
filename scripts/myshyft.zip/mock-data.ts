
import type { User, Shift, PayHistoryEntry, Conversation, Message } from './types';

const MOCK_ORG_ID = 'org_mock_123';

export const MOCK_USERS: User[] = [
  { "uid": "mgmt001", "orgId": MOCK_ORG_ID, "displayName": "Alice Johnson", "email": "alice.mgmt@example.com", "role": "management", photoURL: 'https://i.pravatar.cc/100?u=alice', hasOnboarded: true },
  { "uid": "staff001", "orgId": MOCK_ORG_ID, "displayName": "Bob Smith", "email": "bob.staff@example.com", "role": "staff", photoURL: 'https://i.pravatar.cc/100?u=bob', hasOnboarded: true },
  { "uid": "staff002", "orgId": MOCK_ORG_ID, "displayName": "Clara Lee", "email": "clara.staff@example.com", "role": "staff", photoURL: 'https://i.pravatar.cc/100?u=clara', hasOnboarded: true },
  { "uid": "staff003_new", "orgId": MOCK_ORG_ID, "displayName": "David Green", "email": "david.new@example.com", "role": "staff", photoURL: 'https://i.pravatar.cc/100?u=david', hasOnboarded: false }
];

const today = new Date();
const y = today.getFullYear();
const m = today.getMonth();

const formatDate = (date: Date) => date.toISOString().split('T')[0];

export const MOCK_SHIFTS: Shift[] = [
  { "id": "shift001", "orgId": MOCK_ORG_ID, "userId": "staff001", "date": formatDate(new Date(y, m, 10)), "start": "09:00", "end": "17:00" },
  { "id": "shift002", "orgId": MOCK_ORG_ID, "userId": "staff002", "date": formatDate(new Date(y, m, 10)), "start": "13:00", "end": "21:00" },
  { "id": "shift003", "orgId": MOCK_ORG_ID, "userId": "staff001", "date": formatDate(new Date(y, m, 12)), "start": "08:00", "end": "16:00" }
];

export const MOCK_PAY_HISTORY: PayHistoryEntry[] = [
  { "id": "pay001", "orgId": MOCK_ORG_ID, "userId": "staff001", "periodStart": "2024-07-01", "periodEnd": "2024-07-07", "amount": 1200.50, "currency": "USD" },
  { "id": "pay002", "orgId": MOCK_ORG_ID, "userId": "staff002", "periodStart": "2024-07-01", "periodEnd": "2024-07-07", "amount": 980.75, "currency": "USD" },
  { "id": "pay003", "orgId": MOCK_ORG_ID, "userId": "staff001", "periodStart": "2024-07-08", "periodEnd": "2024-07-14", "amount": 1250.00, "currency": "USD" },
];

const ts = (minutesAgo: number) => ({ seconds: Math.floor(Date.now() / 1000) - minutesAgo * 60, nanoseconds: 0 });

export const MOCK_CONVERSATIONS: Conversation[] = [
  { id: 'conv001', orgId: MOCK_ORG_ID, participants: ['mgmt001', 'staff001'], lastMessage: 'Great, see you then.', lastMessageTimestamp: ts(5) },
  { id: 'conv002', orgId: MOCK_ORG_ID, participants: ['mgmt001', 'staff002'], lastMessage: 'Can you cover the weekend shift?', lastMessageTimestamp: ts(120) },
];

export const MOCK_MESSAGES: Record<string, Message[]> = {
  'conv001': [
    { id: 'msg001', senderId: 'mgmt001', text: 'Hey Bob, can you come in early tomorrow?', timestamp: ts(10) },
    { id: 'msg002', senderId: 'staff001', text: 'Sure, what time?', timestamp: ts(8) },
    { id: 'msg003', senderId: 'mgmt001', text: '8 AM would be great.', timestamp: ts(7) },
    { id: 'msg004', senderId: 'staff001', text: 'No problem, I can do that.', timestamp: ts(6) },
    { id: 'msg005', senderId: 'mgmt001', text: 'Great, see you then.', timestamp: ts(5) },
  ],
  'conv002': [
    { id: 'msg006', senderId: 'mgmt001', text: 'Hi Clara, I have a question about the schedule.', timestamp: ts(125) },
    { id: 'msg007', senderId: 'mgmt001', text: 'Can you cover the weekend shift?', timestamp: ts(120) },
  ],
};
