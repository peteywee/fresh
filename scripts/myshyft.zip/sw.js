// Minimal placeholder SW. Extend with caching strategies as needed.
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  clients.claim();
});
