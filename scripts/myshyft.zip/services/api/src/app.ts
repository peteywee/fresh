import express, { Request, Response } from "express";
import cors from "cors";
import crypto from "crypto";

export function makeApp() {
  const app = express();
  app.use(cors());
  app.use(express.json());

  // Fix: Explicitly type request and response parameters in all handlers to avoid type inference errors.
  app.get("/health", (_req: Request, res: Response) => res.json({ ok: true }));
  app.get("/status", (_req: Request, res: Response) => res.json({ ok: true, time: new Date().toISOString() }));

  // Echo/Probe endpoints
  app.get("/__/probe", (req: Request, res: Response) => {
    res.json({ ok: true, runId: req.header("x-run-id") ?? null, probedAt: new Date().toISOString() });
  });
  app.get("/hierarchy/echo", (req: Request, res: Response) => {
    res.json({
      ok: true,
      hierarchy: {
        runId: req.header("x-run-id") || "run-unknown",
        user: req.header("x-user") || "anonymous",
        object: req.header("x-obj") || "unspecified",
        task: req.header("x-task") || "unspecified",
        step: req.header("x-step") || "unspecified"
      },
      headers: req.headers
    });
  });

  // Onboarding passthrough contract (replace with Firestore later)
  app.post("/api/onboarding/complete", (req: Request, res: Response) => {
    const { user, org } = req.body ?? {};
    if (!user?.email || !user?.displayName || !org?.name) {
        return res.status(400).json({ error: "Invalid payload" });
    }
    const now = new Date().toISOString();
    return res.status(201).json({
      user: { id: crypto.randomUUID(), email: user.email, displayName: user.displayName, orgId: "temp-org", role: "owner" },
      org: { id: "temp-org", name: org.name, createdAt: now }
    });
  });

  return app;
}
