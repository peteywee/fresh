import { makeApp } from "./app.js";

const app = makeApp();
const PORT = Number(process.env.PORT || 3001);

app.listen(PORT, () => {
  console.log(`[api] listening on http://localhost:${PORT}`);
});
