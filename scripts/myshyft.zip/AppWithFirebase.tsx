
import React, { useState, useEffect, useCallback } from 'react';
import { Theme, Environment, Shift, PayHistoryEntry, User, Conversation, Message } from './types';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import PayHistory from './components/PayHistory';
import Settings from './components/Settings';
import Login from './components/Login';
import Messages from './components/Messages';
import Onboarding from './components/Onboarding';
import Welcome from './components/Welcome'; // New component for invited users
import { NAV_ITEMS } from './constants';
import * as firebaseService from './services/firebaseService';

const AppWithFirebase: React.FC = () => {
    const [theme, setTheme] = useState<Theme>(Theme.System);
    const [environment, setEnvironment] = useState<Environment>(Environment.Dev);
    const [activePage, setActivePage] = useState<string>(NAV_ITEMS[0].name);
    
    const [currentUser, setCurrentUser] = useState<Partial<User> | null>(null);
    const [isLoadingAuth, setIsLoadingAuth] = useState(true);
    const [isLoadingData, setIsLoadingData] = useState(false);
    
    const [users, setUsers] = useState<User[]>([]);
    const [shifts, setShifts] = useState<Shift[]>([]);
    const [payHistory, setPayHistory] = useState<PayHistoryEntry[]>([]);
    const [conversations, setConversations] = useState<Conversation[]>([]);
    const [messages, setMessages] = useState<Message[]>([]);
    const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

    const handleUserAuth = useCallback((user: Partial<User> | null) => {
        setCurrentUser(user);
        setIsLoadingAuth(false);
        if (!user || !user.orgId || user.hasOnboarded === false) { // Clear all data on sign out or if onboarding
            setUsers([]);
            setShifts([]);
            setPayHistory([]);
            setConversations([]);
            setMessages([]);
            setActiveConversationId(null);
        }
    }, []);

    useEffect(() => {
        const unsubscribe = firebaseService.onAuthStateChanged(handleUserAuth);
        return () => unsubscribe();
    }, [handleUserAuth]);

    const fetchData = useCallback(async (user: User) => {
        setIsLoadingData(true);
        try {
            const [fetchedUsers, fetchedShifts, fetchedPayHistory] = await Promise.all([
                firebaseService.getUsers(user.orgId),
                firebaseService.getShifts(user.orgId, user),
                firebaseService.getPayHistory(user.orgId, user)
            ]);
            setUsers(fetchedUsers);
            setShifts(fetchedShifts);
            setPayHistory(fetchedPayHistory);
        } catch (error) {
            console.error("Failed to fetch data:", error);
        } finally {
            setIsLoadingData(false);
        }
    }, []);

    useEffect(() => {
        if (currentUser?.uid && currentUser.orgId && currentUser.hasOnboarded) {
            const fullUser = currentUser as User;
            fetchData(fullUser);
            const unsubscribe = firebaseService.onConversations(fullUser.orgId, fullUser.uid, setConversations);
            return () => unsubscribe();
        }
    }, [currentUser, fetchData]);
    
    useEffect(() => {
        if(activeConversationId) {
            const unsubscribe = firebaseService.onMessages(activeConversationId, setMessages);
            return () => unsubscribe();
        } else {
            setMessages([]);
        }
    }, [activeConversationId]);

    useEffect(() => {
        const root = window.document.documentElement;
        const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (theme === Theme.Dark || (theme === Theme.System && isDarkMode)) {
            root.classList.add('dark');
        } else {
            root.classList.remove('dark');
        }
    }, [theme]);
    
    const handleAddShift = async (newShift: Omit<Shift, 'id' | 'orgId'>) => {
        const user = currentUser as User;
        if (!user) return;
        await firebaseService.addShift(user.orgId, newShift);
        await fetchData(user);
    };
    
    const handleUpdateShift = async (shift: Shift) => {
        const user = currentUser as User;
        if (!user) return;
        const { id, ...data } = shift;
        await firebaseService.updateShift(id, data);
        await fetchData(user);
    };
    
    const handleDeleteShift = async (shiftId: string) => {
        const user = currentUser as User;
        if (!user) return;
        await firebaseService.deleteShift(shiftId);
        await fetchData(user);
    };
    
    const handleProfileUpdate = async (data: { displayName?: string; photoFile?: File }) => {
        const user = currentUser as User;
        if (!user) return;
        
        let photoURL = user.photoURL;
        if (data.photoFile) {
            photoURL = await firebaseService.uploadProfilePicture(user.uid, data.photoFile);
        }

        const updateData: { displayName?: string; photoURL?: string } = {};
        if (data.displayName && data.displayName !== user.displayName) {
            updateData.displayName = data.displayName;
        }
        if (photoURL !== user.photoURL) {
            updateData.photoURL = photoURL;
        }

        if (Object.keys(updateData).length > 0) {
            await firebaseService.updateUserProfile(user.uid, updateData);
            setCurrentUser(prevUser => prevUser ? { ...prevUser, ...updateData } : null);
            await fetchData(user);
        }
    };
    
    const handleInvitation = async (email: string, role: 'management' | 'staff') => {
        const user = currentUser as User;
        if (!user) return;
        await firebaseService.sendInvitation(user.orgId, email, role);
    };

    const handleSignOut = () => firebaseService.signOut();

    const handleSendMessage = async (conversationId: string, text: string) => {
        const user = currentUser as User;
        if (!user) return;
        await firebaseService.sendMessage(conversationId, user.uid, text);
    };

    const handleStartConversation = async (otherUserId: string) => {
        const user = currentUser as User;
        if (!user) return;
        const conversationId = await firebaseService.findOrCreateConversation(user.orgId, user.uid, otherUserId);
        setActiveConversationId(conversationId);
        setActivePage('Messages');
    };

    const handleOnboardingComplete = () => {
        // Trigger a re-check of the auth state to get the full user profile
        setIsLoadingAuth(true);
        const unsubscribe = firebaseService.onAuthStateChanged(handleUserAuth);
        setTimeout(unsubscribe, 1500); // Give time for propagation
    };

    const renderContent = () => {
        const fullCurrentUser = currentUser as User;
        if (isLoadingData) {
            return <div className="flex items-center justify-center h-full"><div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-500"></div></div>;
        }

        switch (activePage) {
            case 'Dashboard':
                return <Dashboard shifts={shifts} users={users} onAddShift={handleAddShift} onUpdateShift={handleUpdateShift} onDeleteShift={handleDeleteShift} currentUser={fullCurrentUser} />;
            case 'Messages':
                return <Messages
                            users={users}
                            currentUser={fullCurrentUser}
                            conversations={conversations}
                            activeConversationId={activeConversationId}
                            setActiveConversationId={setActiveConversationId}
                            messages={messages}
                            onSendMessage={handleSendMessage}
                            onStartConversation={handleStartConversation}
                        />;
            case 'Pay History':
                return <PayHistory payHistory={payHistory} users={users} />;
            case 'Settings':
                return <Settings user={fullCurrentUser} onProfileUpdate={handleProfileUpdate} onInvite={handleInvitation} />;
            default:
                return <Dashboard shifts={shifts} users={users} onAddShift={handleAddShift} onUpdateShift={handleUpdateShift} onDeleteShift={handleDeleteShift} currentUser={fullCurrentUser} />;
        }
    };
    
    if (isLoadingAuth) {
        return <div className="flex items-center justify-center h-screen bg-gray-100 dark:bg-gray-900"><div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-500"></div></div>;
    }
    
    if (!currentUser) {
        return <Login />;
    }
    
    // User is authenticated but has no orgId -> needs to create an org
    if (!currentUser.orgId) {
        return <Onboarding user={currentUser} onComplete={handleOnboardingComplete} />;
    }
    
    // User is invited but hasn't completed the welcome screen
    if (currentUser.hasOnboarded === false) {
        return <Welcome user={currentUser as User} onComplete={handleOnboardingComplete} />;
    }

    return (
        <Layout theme={theme} setTheme={setTheme} environment={environment} setEnvironment={setEnvironment} activePage={activePage} setActivePage={setActivePage} user={currentUser as User} onSignOut={handleSignOut}>
            {renderContent()}
        </Layout>
    );
};

export default AppWithFirebase;
