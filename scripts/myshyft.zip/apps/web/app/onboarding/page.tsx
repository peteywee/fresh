'use client';
import { useRouter } from 'next/navigation';
import React from 'react';

export default function OnboardingPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    const formData = new FormData(e.currentTarget);
    const displayName = formData.get('displayName') as string;
    const email = formData.get('email') as string;
    const orgName = formData.get('orgName') as string;

    try {
      const res = await fetch('/api/onboarding/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          user: { displayName, email },
          org: { name: orgName }
        }),
      });

      if (!res.ok) {
        const body = await res.json();
        throw new Error(body.error || 'Onboarding failed');
      }
      
      // Middleware will handle redirect
      router.push('/dashboard');
      router.refresh();

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setIsLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <div className="w-full max-w-sm p-8 space-y-6 bg-white rounded-lg shadow-md">
        <h1 className="text-2xl font-bold text-center">Onboarding</h1>
        <p className="text-center text-gray-600">Let's get you set up.</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="displayName">Display Name</label>
            <input id="displayName" name="displayName" type="text" required defaultValue="Demo User" className="w-full px-3 py-2 mt-1 border rounded-md" />
          </div>
          <div>
            <label htmlFor="email">Email</label>
            <input id="email" name="email" type="email" required defaultValue="demo@example.com" className="w-full px-3 py-2 mt-1 border rounded-md" />
          </div>
           <div>
            <label htmlFor="orgName">Organization Name</label>
            <input id="orgName" name="orgName" type="text" required defaultValue="Fresh Corp" className="w-full px-3 py-2 mt-1 border rounded-md" />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:bg-blue-300"
          >
            {isLoading ? 'Saving...' : 'Complete Onboarding'}
          </button>
          {error && <p className="mt-4 text-sm text-center text-red-500">{error}</p>}
        </form>
      </div>
    </main>
  );
}
