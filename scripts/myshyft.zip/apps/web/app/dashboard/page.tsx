import { getSession } from '@/lib/session';

export default function DashboardPage() {
  const session = getSession();

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <div className="w-full max-w-md p-8 text-center bg-white rounded-lg shadow-md">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        {session ? (
          <p className="mt-4 text-lg">
            Welcome, <span className="font-semibold">{session.displayName}</span> from <span className="font-semibold">{session.orgName}</span>!
          </p>
        ) : (
          <p className="mt-4">Loading session...</p>
        )}
      </div>
    </main>
  );
}
