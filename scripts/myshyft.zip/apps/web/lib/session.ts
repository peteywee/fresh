import { cookies } from 'next/headers';

export interface SessionData {
  loggedIn: boolean;
  onboarded: boolean;
  displayName?: string;
  orgName?: string;
}

export function getSession(): SessionData | null {
  const cookieStore = cookies();
  const sessionCookie = cookieStore.get('__session');

  if (!sessionCookie?.value) {
    return null;
  }

  try {
    const sessionData = JSON.parse(sessionCookie.value);
    return sessionData as SessionData;
  } catch (error) {
    console.error("Failed to parse session cookie:", error);
    return null;
  }
}
