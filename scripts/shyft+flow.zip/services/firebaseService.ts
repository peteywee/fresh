
import { firebaseApp } from '../firebaseConfig';
import firebase from 'firebase/compat/app';
import type { User, Shift, PayHistoryEntry, Conversation, Message, Organization, Invitation } from '../types';

if (!firebaseApp) {
    throw new Error("Firebase is not configured. Please check firebaseConfig.ts");
}

const auth = firebaseApp.auth();
const db = firebaseApp.firestore();
const storage = firebaseApp.storage();
const provider = new firebase.auth.GoogleAuthProvider();

export const signInWithGoogle = async (): Promise<void> => {
    try {
        await auth.signInWithPopup(provider);
    } catch (error) {
        console.error("Error signing in with Google:", error);
        throw error;
    }
};

export const signOut = async (): Promise<void> => {
    try {
        await auth.signOut();
    } catch (error) {
        console.error("Error signing out:", error);
        throw error;
    }
};

export const onAuthStateChanged = (callback: (user: Partial<User> | null) => void): (() => void) => {
    return auth.onAuthStateChanged(async (firebaseUser: firebase.User | null) => {
        if (firebaseUser) {
            // 1. Check if user document already exists
            const userDocRef = db.collection('users').doc(firebaseUser.uid);
            const userDoc = await userDocRef.get();

            if (userDoc.exists) {
                // Existing user, return their full profile
                callback({ uid: firebaseUser.uid, ...userDoc.data() } as User);
                return;
            }

            // 2. Check for an invitation
            const invitationQuery = db.collection('invitations').where('email', '==', firebaseUser.email);
            const invitationSnapshot = await invitationQuery.get();
            
            if (!invitationSnapshot.empty) {
                const invitationDoc = invitationSnapshot.docs[0];
                const invitationData = invitationDoc.data() as Omit<Invitation, 'id'>;

                // Create user from invitation
                const newUser: Omit<User, 'uid'> = {
                    orgId: invitationData.orgId,
                    displayName: firebaseUser.displayName || 'New User',
                    email: firebaseUser.email!,
                    photoURL: firebaseUser.photoURL || `https://i.pravatar.cc/100?u=${firebaseUser.uid}`,
                    role: invitationData.role,
                    hasOnboarded: false, // Invited users need to go through the Welcome screen
                };
                
                // Use a batch to create user and delete invitation atomically
                const batch = db.batch();
                batch.set(userDocRef, newUser);
                batch.delete(invitationDoc.ref);
                await batch.commit();
                
                callback({ uid: firebaseUser.uid, ...newUser });
                return;
            }
            
            // 3. New user with no invitation - needs to create an org
            callback({
                uid: firebaseUser.uid,
                displayName: firebaseUser.displayName || 'New User',
                email: firebaseUser.email!,
                photoURL: firebaseUser.photoURL || `https://i.pravatar.cc/100?u=${firebaseUser.uid}`,
                orgId: undefined, // Signal that org creation is needed
            });

        } else {
            callback(null);
        }
    });
};

export const createOrganizationAndUser = async (user: Partial<User>, orgName: string): Promise<void> => {
    const orgRef = db.collection('organizations').doc();
    const userRef = db.collection('users').doc(user.uid!);

    const newOrg: Omit<Organization, 'id'> = {
        name: orgName,
        ownerUid: user.uid!,
    };
    
    const newUser: Omit<User, 'uid'> = {
        orgId: orgRef.id,
        role: 'management', // First user is always management
        displayName: user.displayName!,
        email: user.email!,
        photoURL: user.photoURL!,
        hasOnboarded: true, // The creator has onboarded by creating the org
    };

    const batch = db.batch();
    batch.set(orgRef, newOrg);
    batch.set(userRef, newUser);
    await batch.commit();
};

export const markUserAsOnboarded = async (userId: string): Promise<void> => {
    const userDocRef = db.collection('users').doc(userId);
    await userDocRef.update({ hasOnboarded: true });
};

export const getOrganization = async (orgId: string): Promise<Organization | null> => {
    const orgDoc = await db.collection('organizations').doc(orgId).get();
    if (!orgDoc.exists) return null;
    return { id: orgDoc.id, ...orgDoc.data() } as Organization;
};


export const sendInvitation = async (orgId: string, email: string, role: 'management' | 'staff'): Promise<void> => {
    const invitationRef = db.collection('invitations').doc(email.toLowerCase());
    await invitationRef.set({ orgId, email: email.toLowerCase(), role });
};


// --- Data fetching functions are now multi-tenant ---

export const getUsers = async (orgId: string): Promise<User[]> => {
    const usersCollection = db.collection('users').where('orgId', '==', orgId);
    const userSnapshot = await usersCollection.get();
    return userSnapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as User));
};

export const getShifts = async (orgId: string, user: User): Promise<Shift[]> => {
    let query: firebase.firestore.Query = db.collection('shifts').where('orgId', '==', orgId);
    if (user.role !== 'management') {
        query = query.where("userId", "==", user.uid);
    }
    const shiftSnapshot = await query.get();
    const shifts = shiftSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Shift));
    return shifts.sort((a,b) => a.date.localeCompare(b.date));
};

export const getPayHistory = async (orgId: string, user: User): Promise<PayHistoryEntry[]> => {
    let query: firebase.firestore.Query = db.collection('payHistory').where('orgId', '==', orgId);
    if (user.role !== 'management') {
        query = query.where("userId", "==", user.uid);
    }
    const payHistorySnapshot = await query.get();
    return payHistorySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as PayHistoryEntry));
};

export const addShift = async (orgId: string, shiftData: Omit<Shift, 'id' | 'orgId'>): Promise<void> => {
    await db.collection('shifts').add({ ...shiftData, orgId });
};

export const updateShift = async (shiftId: string, shiftData: Partial<Omit<Shift, 'id'>>): Promise<void> => {
    const shiftRef = db.collection('shifts').doc(shiftId);
    await shiftRef.update(shiftData);
};

export const deleteShift = async (shiftId: string): Promise<void> => {
    const shiftRef = db.collection('shifts').doc(shiftId);
    await shiftRef.delete();
};

export const uploadProfilePicture = async (userId: string, file: File): Promise<string> => {
    const filePath = `users/${userId}/profile.jpg`;
    const storageRef = storage.ref(filePath);
    await storageRef.put(file);
    const downloadURL = await storageRef.getDownloadURL();
    return downloadURL;
};

export const updateUserProfile = async (userId: string, data: { displayName?: string, photoURL?: string }): Promise<void> => {
    const user = auth.currentUser;
    if (!user || user.uid !== userId) throw new Error("Authentication error");
    
    await user.updateProfile(data);

    const userDocRef = db.collection('users').doc(userId);
    await userDocRef.update(data);
};

// --- Messaging Functions ---

export const onConversations = (orgId: string, userId: string, callback: (conversations: Conversation[]) => void): (() => void) => {
    const query = db.collection('conversations')
        .where('orgId', '==', orgId)
        .where('participants', 'array-contains', userId)
        .orderBy('lastMessageTimestamp', 'desc');
    return query.onSnapshot(snapshot => {
        const conversations = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Conversation));
        callback(conversations);
    }, error => console.error("Error fetching conversations:", error));
};

export const onMessages = (conversationId: string, callback: (messages: Message[]) => void): (() => void) => {
    const query = db.collection('conversations').doc(conversationId).collection('messages').orderBy('timestamp', 'asc');
    return query.onSnapshot(snapshot => {
        const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
        callback(messages);
    }, error => console.error(`Error fetching messages for ${conversationId}:`, error));
};

export const sendMessage = async (conversationId: string, senderId: string, text: string): Promise<void> => {
    if (!text.trim()) return;
    const conversationRef = db.collection('conversations').doc(conversationId);
    const messageRef = conversationRef.collection('messages').doc();

    const timestamp = firebase.firestore.FieldValue.serverTimestamp();

    const batch = db.batch();
    batch.set(messageRef, { senderId, text, timestamp });
    batch.update(conversationRef, { lastMessage: text, lastMessageTimestamp: timestamp });

    await batch.commit();
};

export const findOrCreateConversation = async (orgId: string, currentUserId: string, otherUserId: string): Promise<string> => {
    const participants = [currentUserId, otherUserId].sort();
    const querySnapshot = await db.collection('conversations')
        .where('orgId', '==', orgId)
        .where('participants', '==', participants)
        .limit(1)
        .get();

    if (!querySnapshot.empty) {
        return querySnapshot.docs[0].id;
    } else {
        const newConversationRef = db.collection('conversations').doc();
        await newConversationRef.set({
            orgId,
            participants,
            lastMessage: `Conversation started.`,
            lastMessageTimestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
        return newConversationRef.id;
    }
};
