
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import type { User, Shift } from '../types';

// Ensure the API_KEY is available in the environment variables
// Use the same key as Firebase for simplicity, as it's a Google Cloud API key.
const apiKey = process.env.NEXT_PUBLIC_FIREBASE_API_KEY;

// This flag checks if you have filled in your API key.
const isGeminiConfigured = !!apiKey && apiKey !== 'YOUR_API_KEY';

if (!isGeminiConfigured) {
  // This approach is for developer convenience. In a real-world production
  // environment, this check would ideally happen at build or deploy time.
  console.warn("Gemini AI key not configured or is a placeholder. AI assistant will use mocked responses.");
}

// Initialize with a valid key or an empty string to prevent constructor errors.
const ai = new GoogleGenAI({ apiKey: isGeminiConfigured ? apiKey : "" });

/**
 * Calls the Gemini API to get a response from the AI assistant.
 * @param prompt - The user's question for the AI assistant.
 * @returns The text response from the model.
 */
export async function askAiAssistant(prompt: string): Promise<string> {
    if (!isGeminiConfigured) {
        // Return a mocked response if the API key is not configured.
        // This allows the UI to function without a valid key for development.
        return new Promise(resolve => setTimeout(() => resolve(`This is a mocked AI response for your question: "${prompt}". Please configure your API key to get a real answer.`), 1000));
    }

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `You are an expert HR and staff management assistant for a company using 'Shyft'. Provide helpful, concise, and actionable advice. Answer the following question from a manager: "${prompt}"`,
            config: {
                temperature: 0.7,
                topP: 1,
                topK: 1,
                maxOutputTokens: 2048,
            },
        });
        
        const text = response.text;
        
        if (!text) {
          throw new Error("Received an empty response from the AI.");
        }
        
        return text.trim();
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        if (error instanceof Error) {
            // Provide a more user-friendly error message
            return Promise.reject(new Error(`Failed to get response from AI assistant. Reason: ${error.message}`));
        }
        return Promise.reject(new Error("An unexpected error occurred while contacting the AI assistant."));
    }
}

type GeneratedShift = Omit<Shift, 'id' | 'orgId'>;

/**
 * Calls the Gemini API to generate a schedule from a prompt.
 * @param prompt - The manager's prompt for the schedule.
 * @param users - The list of available staff users.
 * @returns A promise that resolves to an array of generated shift objects.
 */
export async function generateSchedule(prompt: string, users: User[]): Promise<GeneratedShift[]> {
    if (!isGeminiConfigured) {
        const today = new Date();
        const y = today.getFullYear();
        const m = today.getMonth();
        const d = today.getDate();
        const formatDate = (date: Date) => date.toISOString().split('T')[0];
        // Return a mocked response if the API key is not configured.
        return new Promise(resolve => setTimeout(() => resolve([
            { userId: users[0].uid, date: formatDate(new Date(y,m,d+1)), start: '09:00', end: '17:00' },
            { userId: users[1].uid, date: formatDate(new Date(y,m,d+1)), start: '10:00', end: '18:00' },
        ]), 1500));
    }

    const userList = users.map(u => `- ${u.displayName} (id: ${u.uid})`).join('\n');

    const fullPrompt = `
        You are an expert schedule generator for a company using 'Shyft'.
        Your task is to create a schedule based on the manager's request.
        Today's date is ${new Date().toDateString()}.
        
        Available Staff (use their ID for the 'userId' field):
        ${userList}
        
        Manager's Request: "${prompt}"
        
        Generate the schedule and return it as a JSON array of shift objects.
        Each shift object must have 'userId', 'date' (in YYYY-MM-DD format), 'start' (in HH:mm 24-hour format), and 'end' (in HH:mm 24-hour format).
        Ensure the 'userId' matches one of the provided staff IDs.
    `;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: fullPrompt,
            config: {
                temperature: 0.5,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            userId: { type: Type.STRING, description: "The ID of the staff member for this shift." },
                            date: { type: Type.STRING, description: "The date of the shift in YYYY-MM-DD format." },
                            start: { type: Type.STRING, description: "The start time of the shift in HH:mm format." },
                            end: { type: Type.STRING, description: "The end time of the shift in HH:mm format." },
                        },
                        required: ["userId", "date", "start", "end"],
                    },
                },
            },
        });
        
        const jsonStr = response.text;
        if (!jsonStr) {
            throw new Error("Received an empty schedule from the AI.");
        }
        
        const generatedShifts = JSON.parse(jsonStr.trim());
        
        if (!Array.isArray(generatedShifts)) {
            console.error("AI response was not a valid array:", generatedShifts);
            throw new Error("AI response is not in the expected format.");
        }
        return generatedShifts as GeneratedShift[];

    } catch (error) {
        console.error("Error calling Gemini API for schedule generation:", error);
        if (error instanceof Error) {
            return Promise.reject(new Error(`Failed to generate schedule. Reason: ${error.message}`));
        }
        return Promise.reject(new Error("An unexpected error occurred while generating the schedule."));
    }
}
