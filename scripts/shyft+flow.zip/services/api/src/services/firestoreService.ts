import { db } from '../firebase.js';
import crypto from 'crypto';
import { 
  OrganizationSchema, 
  UserSchema, 
  OnboardingPayloadSchema 
} from '@packages/types';
import { z } from 'zod';

type OnboardingPayload = z.infer<typeof OnboardingPayloadSchema>;

/**
 * Creates a new organization and the initial user within a Firestore batch write.
 * @param payload The raw onboarding data from the request body.
 * @returns The newly created user and organization documents.
 */
export async function createOrganizationAndUser(payload: unknown) {
    // 1. Validate the incoming payload against the Zod schema.
    const validation = OnboardingPayloadSchema.safeParse(payload);
    if (!validation.success) {
        // Combine Zod errors into a single message for a clear client response.
        const errorMessage = validation.error.errors.map(e => e.message).join(', ');
        throw new Error(`Invalid payload: ${errorMessage}`);
    }
    const { user: userData, org: orgData } = validation.data;

    // 2. Generate necessary IDs and timestamps.
    const newUserId = crypto.randomUUID();
    const newOrgId = crypto.randomUUID();
    const now = new Date().toISOString();

    // 3. Prepare the organization document.
    const orgDoc: z.infer<typeof OrganizationSchema> = {
        id: newOrgId,
        name: orgData.name,
        createdAt: now,
        ownerId: newUserId,
    };
    
    // 4. Prepare the user document. The first user is always an admin.
    const userDoc: z.infer<typeof UserSchema> = {
        id: newUserId,
        email: userData.email,
        displayName: userData.displayName,
        orgId: newOrgId,
        role: 'admin',
        onboardingComplete: true,
    };

    // 5. Define Firestore document references.
    const orgRef = db.collection('organizations').doc(newOrgId);
    // As per the brief, users are stored in a subcollection of their organization.
    const userRef = db.collection('organizations').doc(newOrgId).collection('users').doc(newUserId);

    // 6. Execute an atomic batch write to ensure data consistency.
    const batch = db.batch();
    batch.set(orgRef, orgDoc);
    batch.set(userRef, userDoc);
    await batch.commit();

    // 7. Return the newly created documents.
    return { user: userDoc, org: orgDoc };
}
