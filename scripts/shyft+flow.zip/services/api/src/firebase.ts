import admin from 'firebase-admin';

// Initialize Firebase Admin SDK
// In a deployed Firebase environment (like Cloud Functions), the SDK is automatically
// configured. For local development using emulators, you need to have the
// FIRESTORE_EMULATOR_HOST environment variable set.
if (!admin.apps.length) {
  admin.initializeApp();
}

export const db = admin.firestore();
