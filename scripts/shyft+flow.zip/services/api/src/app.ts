// Fix: Corrected express import and type annotations to resolve type errors.
import express, { Request, Response } from "express";
import cors from "cors";
import { createOrganizationAndUser } from "./services/firestoreService.js";

export function makeApp() {
  const app = express();
  app.use(cors());
  app.use(express.json());

  app.get("/health", (_req: Request, res: Response) => res.json({ ok: true }));
  app.get("/status", (_req: Request, res: Response) => res.json({ ok: true, time: new Date().toISOString() }));

  // Echo/Probe endpoints
  app.get("/__/probe", (req: Request, res: Response) => {
    res.json({ ok: true, runId: req.header("x-run-id") ?? null, probedAt: new Date().toISOString() });
  });
  app.get("/hierarchy/echo", (req: Request, res: Response) => {
    res.json({
      ok: true,
      hierarchy: {
        runId: req.header("x-run-id") || "run-unknown",
        user: req.header("x-user") || "anonymous",
        object: req.header("x-obj") || "unspecified",
        task: req.header("x-task") || "unspecified",
        step: req.header("x-step") || "unspecified"
      },
      headers: req.headers
    });
  });

  // Onboarding endpoint with Firestore integration
  app.post("/api/onboarding/complete", async (req: Request, res: Response) => {
    try {
      const { user, org } = await createOrganizationAndUser(req.body);
      return res.status(201).json({ user, org });
    } catch (error) {
      console.error('Onboarding process failed:', error);
      if (error instanceof Error && error.message.includes("Invalid payload")) {
        return res.status(400).json({ error: error.message });
      }
      return res.status(500).json({ error: "An internal error occurred during onboarding." });
    }
  });


  return app;
}
