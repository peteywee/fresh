import { z } from "zod";

// Schemas for data validation during onboarding
export const OnboardingUserSchema = z.object({
  displayName: z.string().min(1, "Display name cannot be empty."),
  email: z.string().email("Invalid email address."),
});

export const OnboardingOrgSchema = z.object({
  name: z.string().min(1, "Organization name cannot be empty."),
});

export const OnboardingPayloadSchema = z.object({
  user: OnboardingUserSchema,
  org: OnboardingOrgSchema,
});

// Schemas representing documents in Firestore
export const UserSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  displayName: z.string().min(1),
  orgId: z.string().uuid(),
  role: z.enum(["admin", "staff", "viewer"]),
  onboardingComplete: z.boolean()
});
export type User = z.infer<typeof UserSchema>;

export const OrganizationSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1),
  createdAt: z.string().datetime(),
  ownerId: z.string().uuid()
});
export type Organization = z.infer<typeof OrganizationSchema>;

export const ScheduleEntrySchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  orgId: z.string().uuid(),
  startTime: z.string().datetime(),
  endTime: z.string().datetime(),
  role: z.string().min(1)
});
export type ScheduleEntry = z.infer<typeof ScheduleEntrySchema>;
