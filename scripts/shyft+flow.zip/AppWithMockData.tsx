
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Theme, Environment, Shift, PayHistoryEntry, User, Conversation, Message } from './types';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import PayHistory from './components/PayHistory';
import Settings from './components/Settings';
import Messages from './components/Messages';
import Welcome from './components/Welcome';
import ErrorBoundary from './components/ErrorBoundary';
import { NAV_ITEMS } from './constants';
import { MOCK_USERS, MOCK_SHIFTS, MOCK_PAY_HISTORY, MOCK_CONVERSATIONS, MOCK_MESSAGES } from './mock-data';

const UserSwitcherBanner = ({ users, currentUserId, onSwitchUser }: { users: User[], currentUserId: string, onSwitchUser: (uid: string) => void }) => {
    return (
        <div className="bg-indigo-600 text-white p-2 text-center text-sm">
            <span className="font-semibold">Demo Mode:</span>
            <span className="ml-2">Viewing as:</span>
            <select
                value={currentUserId}
                onChange={(e) => onSwitchUser(e.target.value)}
                className="ml-2 bg-indigo-700 border border-indigo-500 rounded-md p-1 text-xs focus:outline-none focus:ring-2 focus:ring-white/50"
            >
                {users.map(user => (
                    <option key={user.uid} value={user.uid}>
                        {user.displayName} ({user.role}) {user.hasOnboarded === false ? '[New]' : ''}
                    </option>
                ))}
            </select>
        </div>
    );
};

function AppWithMockData() {
  const [theme, setTheme] = useState<Theme>(Theme.System);
  const [environment, setEnvironment] = useState<Environment>(Environment.Dev);
  const [activePage, setActivePage] = useState<string>(NAV_ITEMS[0].name);
  
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [shifts, setShifts] = useState<Shift[]>(MOCK_SHIFTS);
  const [payHistory] = useState<PayHistoryEntry[]>(MOCK_PAY_HISTORY);
  
  const [currentUserId, setCurrentUserId] = useState<string>(MOCK_USERS.find(u => u.role === 'management')?.uid || MOCK_USERS[0].uid);

  const [conversations, setConversations] = useState<Conversation[]>(MOCK_CONVERSATIONS);
  const [messagesByConversation, setMessagesByConversation] = useState<Record<string, Message[]>>(MOCK_MESSAGES);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

  const currentUser = useMemo(() => users.find(u => u.uid === currentUserId)!, [users, currentUserId]);

  useEffect(() => {
    const root = window.document.documentElement;
    const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (theme === Theme.Dark || (theme === Theme.System && isDarkMode)) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);
  
  const handleAddShift = (newShift: Omit<Shift, 'id' | 'orgId'>) => setShifts(s => [...s, { ...newShift, id: `s_${Date.now()}`, orgId: currentUser.orgId }]);
  const handleUpdateShift = (updatedShift: Shift) => setShifts(s => s.map(shift => shift.id === updatedShift.id ? updatedShift : shift));
  const handleDeleteShift = (shiftId: string) => setShifts(s => s.filter(shift => shift.id !== shiftId));
  const handleProfileUpdate = async (data: { displayName?: string; photoFile?: File }) => {
    setUsers(u => u.map(user => user.uid === currentUser.uid ? { ...user, displayName: data.displayName || user.displayName, photoURL: data.photoFile ? `https://i.pravatar.cc/100?u=${Date.now()}` : user.photoURL } : user));
  };
  const handleInvitation = async (email: string, role: 'management' | 'staff') => {
    console.log(`Mock invitation sent to ${email} with role ${role} for org ${currentUser.orgId}`);
    alert(`Invitation sent to ${email} with role ${role}.`);
  };
  
  const userShifts = useMemo(() => shifts.filter(s => s.orgId === currentUser.orgId && (currentUser.role === 'management' || s.userId === currentUser.uid)), [currentUser, shifts]);
  const userPayHistory = useMemo(() => payHistory.filter(p => p.orgId === currentUser.orgId && (currentUser.role === 'management' || p.userId === currentUser.uid)), [currentUser, payHistory]);
  const userConversations = useMemo(() => conversations.filter(c => c.orgId === currentUser.orgId && c.participants.includes(currentUser.uid)), [currentUser, conversations]);
  const activeMessages = useMemo(() => (activeConversationId ? messagesByConversation[activeConversationId] || [] : []), [activeConversationId, messagesByConversation]);

  const handleSendMessage = useCallback((conversationId: string, text: string) => {
    if (!text.trim()) return;
    
    const newMessage: Message = {
      id: `m_${Date.now()}`,
      senderId: currentUser.uid,
      text,
      timestamp: { seconds: Date.now() / 1000, nanoseconds: 0 }
    };

    setMessagesByConversation(prev => ({
        ...prev,
        [conversationId]: [...(prev[conversationId] || []), newMessage]
    }));

    setConversations(prev => prev.map(c => c.id === conversationId ? { ...c, lastMessage: text, lastMessageTimestamp: newMessage.timestamp } : c).sort((a,b) => (b.lastMessageTimestamp?.seconds || 0) - (a.lastMessageTimestamp?.seconds || 0)));
  }, [currentUser.uid]);
  
  const handleStartConversation = useCallback((otherUserId: string) => {
    const existing = conversations.find(c => c.orgId === currentUser.orgId && c.participants.includes(currentUser.uid) && c.participants.includes(otherUserId));
    if (existing) {
        setActiveConversationId(existing.id);
    } else {
        const newConversation: Conversation = {
            id: `c_${Date.now()}`,
            orgId: currentUser.orgId,
            participants: [currentUser.uid, otherUserId],
            lastMessage: "Conversation started.",
            lastMessageTimestamp: { seconds: Date.now() / 1000, nanoseconds: 0 },
        };
        setConversations(prev => [newConversation, ...prev]);
        setMessagesByConversation(prev => ({ ...prev, [newConversation.id]: [] }));
        setActiveConversationId(newConversation.id);
    }
    setActivePage('Messages');
  }, [currentUser.uid, currentUser.orgId, conversations]);

  const handleMockOnboardingComplete = () => {
    setUsers(prev => prev.map(u => u.uid === currentUser.uid ? { ...u, hasOnboarded: true } : u));
  };
  
  if (currentUser.hasOnboarded === false) {
    // This is a new, invited user in mock mode
    return <Welcome user={currentUser} onComplete={handleMockOnboardingComplete} isMock={true} />;
  }

  const renderContent = () => {
    switch (activePage) {
      case 'Dashboard':
        return <ErrorBoundary fallbackMessage="The dashboard could not be loaded."><Dashboard shifts={userShifts} users={users} onAddShift={handleAddShift} onUpdateShift={handleUpdateShift} onDeleteShift={handleDeleteShift} currentUser={currentUser} /></ErrorBoundary>;
      case 'Messages':
        return <ErrorBoundary fallbackMessage="Messages could not be loaded."><Messages 
                    users={users}
                    currentUser={currentUser}
                    conversations={userConversations}
                    activeConversationId={activeConversationId}
                    setActiveConversationId={setActiveConversationId}
                    messages={activeMessages}
                    onSendMessage={handleSendMessage}
                    onStartConversation={handleStartConversation}
                /></ErrorBoundary>;
      case 'Pay History':
        return <ErrorBoundary fallbackMessage="Pay history could not be loaded."><PayHistory payHistory={userPayHistory} users={users} /></ErrorBoundary>;
      case 'Settings':
        return <ErrorBoundary fallbackMessage="Settings could not be loaded."><Settings user={currentUser} onProfileUpdate={handleProfileUpdate} onInvite={handleInvitation} /></ErrorBoundary>;
      default:
        return <ErrorBoundary fallbackMessage="The dashboard could not be loaded."><Dashboard shifts={userShifts} users={users} onAddShift={handleAddShift} onUpdateShift={handleUpdateShift} onDeleteShift={handleDeleteShift} currentUser={currentUser} /></ErrorBoundary>;
    }
  };

  return (
    <>
      <UserSwitcherBanner users={users.filter(u => u.orgId === currentUser.orgId)} currentUserId={currentUserId} onSwitchUser={setCurrentUserId} />
      <Layout
        theme={theme}
        setTheme={setTheme}
        environment={environment}
        setEnvironment={setEnvironment}
        activePage={activePage}
        setActivePage={setActivePage}
        user={currentUser}
      >
        {renderContent()}
      </Layout>
    </>
  );
}

export default AppWithMockData;