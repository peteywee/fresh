import { type NavigationItem, Environment } from './types';
import { DashboardIcon, PayHistoryIcon, SettingsIcon, MessagesIcon } from './components/icons';

export const NAV_ITEMS: NavigationItem[] = [
  { name: 'Dashboard', icon: DashboardIcon },
  { name: 'Messages', icon: MessagesIcon },
  { name: 'Pay History', icon: PayHistoryIcon },
  { name: 'Settings', icon: SettingsIcon },
];

export const ENVIRONMENTS: { value: Environment; label: string; color: string }[] = [
  { value: Environment.Dev, label: 'DEV', color: 'bg-dev' },
  { value: Environment.Stage, label: 'STAGE', color: 'bg-stage' },
  { value: Environment.Prod, label: 'PROD', color: 'bg-prod' },
];