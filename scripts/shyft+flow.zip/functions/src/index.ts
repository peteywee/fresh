import * as functions from "firebase-functions";
import { makeApp } from "@services/api/dist/app.js";

const app = makeApp();
export const api = functions.https.onRequest(app);
