
import type React from 'react';

export enum Theme {
  Light = 'light',
  Dark = 'dark',
  System = 'system',
}

export enum Environment {
  Dev = 'dev',
  Stage = 'stage',
  Prod = 'prod',
}

export interface User {
  uid: string;
  orgId: string;
  displayName: string;
  email: string;
  role: 'management' | 'staff';
  photoURL: string;
  hasOnboarded?: boolean;
}

export interface Organization {
    id: string;
    name: string;
    ownerUid: string;
}

export interface Invitation {
    id: string;
    orgId: string;
    email: string;
    role: 'management' | 'staff';
}

export interface Shift {
  id: string;
  orgId: string;
  userId: string;
  date: string; // YYYY-MM-DD
  start: string; // HH:mm
  end: string; // HH:mm
}

export interface PayHistoryEntry {
    id: string;
    orgId: string;
    userId: string;
    periodStart: string; // YYYY-MM-DD
    periodEnd: string; // YYYY-MM-DD
    amount: number;
    currency: string;
}

export interface NavigationItem {
  name: string;
  icon: (props: { className?: string }) => React.ReactNode;
}

export interface Conversation {
  id: string;
  orgId: string;
  participants: string[];
  lastMessage?: string;
  lastMessageTimestamp?: {
    seconds: number;
    nanoseconds: number;
  } | null;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: {
    seconds: number;
    nanoseconds: number;
  } | null;
}
