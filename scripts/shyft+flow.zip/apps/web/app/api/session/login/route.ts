import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function POST() {
  const sessionData = {
    loggedIn: true,
    onboarded: false,
  };

  cookies().set('__session', JSON.stringify(sessionData), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 7, // 1 week
  });

  return NextResponse.json({ success: true });
}
