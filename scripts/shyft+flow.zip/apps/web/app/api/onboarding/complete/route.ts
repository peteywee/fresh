import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function POST(request: Request) {
  const body = await request.json();
  const { user, org } = body;
  
  if (!user?.displayName || !user?.email || !org?.name) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  // In a real app, this would proxy to your backend API.
  // For this prototype, we'll simulate the call and assume success.
  const apiBaseUrl = process.env.API_BASE_URL;
  if (apiBaseUrl) {
      try {
        const apiResponse = await fetch(`${apiBaseUrl}/api/onboarding/complete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
        if (!apiResponse.ok) {
            console.error("API proxy failed:", await apiResponse.text());
            return NextResponse.json({ error: 'API request failed' }, { status: 502 });
        }
      } catch (error) {
        console.error("API proxy fetch error:", error);
        return NextResponse.json({ error: 'Could not connect to API' }, { status: 504 });
      }
  }

  const sessionData = {
    loggedIn: true,
    onboarded: true,
    displayName: user.displayName,
    orgName: org.name,
  };
  
  cookies().set('__session', JSON.stringify(sessionData), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 7, // 1 week
  });

  return NextResponse.json({ success: true });
}
