// This page is protected. 
// The middleware will redirect the user to /login if they are not authenticated,
// or to /dashboard if they are.
export default function HomePage() {
  return null;
}
