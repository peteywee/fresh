import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

interface SessionData {
  loggedIn?: boolean;
  onboarded?: boolean;
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const sessionCookie = request.cookies.get('__session');
  let session: SessionData = {};

  if (sessionCookie?.value) {
    try {
      session = JSON.parse(sessionCookie.value);
    } catch {
      // Corrupt cookie, treat as logged out
      session = {};
    }
  }
  
  const isPublicPage = pathname === '/login';

  // If user is not logged in and not on the login page, redirect to login
  if (!session.loggedIn && !isPublicPage) {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  // If user is logged in
  if (session.loggedIn) {
    // If not onboarded and not on the onboarding page, redirect to onboarding
    if (!session.onboarded && pathname !== '/onboarding') {
      return NextResponse.redirect(new URL('/onboarding', request.url));
    }
    
    // If fully onboarded and trying to access login or root, redirect to dashboard
    if (session.onboarded && (isPublicPage || pathname === '/' || pathname === '/onboarding')) {
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};
