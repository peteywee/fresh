
import React from 'react';
import { NAV_ITEMS } from '../constants';
import { LogoIcon } from './icons';

interface SidebarProps {
  activePage: string;
  setActivePage: (page: string) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage, isOpen, setIsOpen }) => {
  const handleNavClick = (pageName: string) => {
    setActivePage(pageName);
    setIsOpen(false); // Close sidebar on navigation
  };

  return (
    <>
      {/* Overlay for mobile */}
      <div 
        className={`fixed inset-0 bg-black/50 z-30 md:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsOpen(false)}
        aria-hidden="true"
      ></div>

      {/* Sidebar */}
      <div className={`fixed top-0 left-0 h-full z-40 flex flex-col w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transform transition-transform duration-300 ease-in-out md:relative md:transform-none md:z-auto
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-center h-20 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
          <div className="flex items-center space-x-2">
             <LogoIcon className="h-8 w-8 text-indigo-500" />
             <span className="text-2xl font-bold text-gray-800 dark:text-white">Shyft</span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          <nav className="flex-1 px-2 py-4 space-y-2">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.name}
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.name);
                }}
                className={`flex items-center px-4 py-2 text-gray-600 dark:text-gray-400 rounded-lg transition-colors duration-200 ${
                  activePage === item.name
                    ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-300'
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700 hover:text-gray-700 dark:hover:text-gray-200'
                }`}
              >
                <item.icon className="h-6 w-6" />
                <span className="ml-3">{item.name}</span>
              </a>
            ))}
          </nav>
        </div>
      </div>
    </>
  );
};

export default Sidebar;