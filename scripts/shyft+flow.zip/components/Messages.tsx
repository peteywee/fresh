import React, { useState } from 'react';
import type { User, Conversation, Message } from '../types';
import ConversationList from './ConversationList';
import ChatView from './ChatView';
import NewMessageModal from './NewMessageModal';
import { PlusIcon } from './icons';

interface MessagesProps {
  users: User[];
  currentUser: User;
  conversations: Conversation[];
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;
  messages: Message[];
  onSendMessage: (conversationId: string, text: string) => void;
  onStartConversation: (userId: string) => void;
}

const Messages: React.FC<MessagesProps> = (props) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const activeConversation = props.conversations.find(c => c.id === props.activeConversationId);
  const otherUsers = props.users.filter(u => u.uid !== props.currentUser.uid);

  return (
    <div className="flex h-[calc(100vh-5rem)]">
      {isModalOpen && (
        <NewMessageModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          users={otherUsers}
          onStartConversation={(userId) => {
            props.onStartConversation(userId);
            setIsModalOpen(false);
          }}
        />
      )}
      
      {/* Sidebar with conversations */}
      <aside className="w-full md:w-1/3 lg:w-1/4 h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">Messages</h1>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="p-2 rounded-full text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/50 hover:bg-indigo-200 dark:hover:bg-indigo-900" 
            aria-label="New Message">
              <PlusIcon className="w-5 h-5" />
          </button>
        </div>
        <ConversationList
          users={props.users}
          currentUser={props.currentUser}
          conversations={props.conversations}
          activeConversationId={props.activeConversationId}
          onSelectConversation={props.setActiveConversationId}
        />
      </aside>

      {/* Main chat view */}
      <main className="hidden md:flex flex-1 flex-col h-full">
        {activeConversation ? (
          <ChatView
            key={props.activeConversationId}
            users={props.users}
            currentUser={props.currentUser}
            conversation={activeConversation}
            messages={props.messages}
            onSendMessage={props.onSendMessage}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center text-center text-gray-500 dark:text-gray-400">
            <div>
              <p className="text-lg font-semibold">Select a conversation</p>
              <p className="mt-1">Or start a new one to begin chatting.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default Messages;