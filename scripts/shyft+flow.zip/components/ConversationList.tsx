import React from 'react';
import type { User, Conversation } from '../types';

interface ConversationListProps {
  users: User[];
  currentUser: User;
  conversations: Conversation[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
}

const ConversationList: React.FC<ConversationListProps> = ({ users, currentUser, conversations, activeConversationId, onSelectConversation }) => {
    
  const getUserById = (uid: string) => users.find(u => u.uid === uid);

  return (
    <div className="flex-1 overflow-y-auto">
        <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {conversations.map(conv => {
                const otherParticipantId = conv.participants.find(p => p !== currentUser.uid);
                if (!otherParticipantId) return null;
                
                const otherUser = getUserById(otherParticipantId);
                if (!otherUser) return null;

                const isActive = conv.id === activeConversationId;

                return (
                    <li key={conv.id}>
                        <button
                            onClick={() => onSelectConversation(conv.id)}
                            className={`w-full text-left p-4 flex items-center space-x-3 transition-colors duration-150 ${
                                isActive ? 'bg-indigo-100 dark:bg-indigo-900/50' : 'hover:bg-gray-100 dark:hover:bg-gray-700/50'
                            }`}
                        >
                            <img className="h-10 w-10 rounded-full object-cover" src={otherUser.photoURL} alt={otherUser.displayName} />
                            <div className="flex-1 min-w-0">
                                <p className="font-semibold text-sm text-gray-800 dark:text-gray-200 truncate">{otherUser.displayName}</p>
                                <p className={`text-sm truncate ${isActive ? 'text-gray-600 dark:text-gray-300' : 'text-gray-500 dark:text-gray-400'}`}>
                                    {conv.lastMessage}
                                </p>
                            </div>
                        </button>
                    </li>
                );
            })}
             {conversations.length === 0 && (
                <div className="p-8 text-center text-gray-500 dark:text-gray-400">
                    <p>No conversations yet.</p>
                </div>
            )}
        </ul>
    </div>
  );
};

export default ConversationList;