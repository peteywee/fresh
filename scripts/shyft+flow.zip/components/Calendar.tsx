import React, { useState, useMemo } from 'react';
import type { Shift, User } from '../types';
import { PlusIcon, ChevronLeftIcon, ChevronRightIcon, TrashIcon } from './icons';

interface CalendarProps {
    shifts: Shift[];
    users: User[];
    onAddShiftClick: (date: string) => void;
    onEditShiftClick: (shift: Shift) => void;
    onDeleteShift: (shiftId: string) => void;
    userRole: 'management' | 'staff';
}

const Calendar: React.FC<CalendarProps> = ({ shifts, users, onAddShiftClick, onEditShiftClick, onDeleteShift, userRole }) => {
    const [currentDate, setCurrentDate] = useState(new Date());

    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

    const daysInMonth = Array.from({ length: lastDayOfMonth.getDate() }, (_, i) => i + 1);
    const startingDayOfWeek = firstDayOfMonth.getDay();

    const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));

    const getUser = useMemo(() => {
        const userMap = new Map(users.map(u => [u.uid, u]));
        return (userId: string) => userMap.get(userId);
    }, [users]);
    
    const shiftsByDate = useMemo(() => {
        return shifts.reduce((acc, shift) => {
            (acc[shift.date] = acc[shift.date] || []).push(shift);
            return acc;
        }, {} as Record<string, Shift[]>);
    }, [shifts]);

    const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    const handleDelete = (e: React.MouseEvent, shiftId: string) => {
        e.stopPropagation();
        if (window.confirm('Are you sure you want to delete this shift?')) {
            onDeleteShift(shiftId);
        }
    };

    return (
        <div className="mt-8 bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-800 dark:text-white">
                    {currentDate.toLocaleString('default', { month: 'long' })} {currentDate.getFullYear()}
                </h2>
                <div className="flex items-center space-x-2">
                    <button onClick={prevMonth} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" aria-label="Previous month">
                        <ChevronLeftIcon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    </button>
                    <button onClick={nextMonth} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" aria-label="Next month">
                        <ChevronRightIcon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    </button>
                </div>
            </div>
            
            <div className="grid grid-cols-7 gap-px text-center text-sm text-gray-500 dark:text-gray-400 bg-gray-200 dark:bg-gray-700 border-t border-l border-gray-200 dark:border-gray-700">
                {weekDays.map(day => (
                    <div key={day} className="py-2 bg-white dark:bg-gray-800 font-medium">{day}</div>
                ))}
                {Array.from({ length: startingDayOfWeek }).map((_, i) => (
                    <div key={`empty-${i}`} className="bg-gray-50 dark:bg-gray-800/50"></div>
                ))}
                {daysInMonth.map(day => {
                    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                    const dayShifts = shiftsByDate[dateStr] || [];
                    
                    return (
                        <div key={day} className="relative min-h-[120px] bg-white dark:bg-gray-800 p-2 text-left border-b border-r border-gray-200 dark:border-gray-700 flex flex-col group">
                            <time dateTime={dateStr} className="font-semibold text-gray-800 dark:text-gray-200">{day}</time>
                            <div className="flex-grow overflow-y-auto mt-1 space-y-1">
                                {dayShifts.map(shift => {
                                    const user = getUser(shift.userId);
                                    const canInteract = userRole === 'management';
                                    return (
                                        <button 
                                            key={shift.id} 
                                            onClick={() => canInteract && onEditShiftClick(shift)}
                                            disabled={!canInteract}
                                            className={`relative w-full text-left text-xs p-1 rounded transition-colors ${canInteract ? 'bg-indigo-100 dark:bg-indigo-900/70 hover:bg-indigo-200 dark:hover:bg-indigo-900/90 text-indigo-700 dark:text-indigo-200 cursor-pointer' : 'bg-gray-100 dark:bg-gray-700/50 text-gray-700 dark:text-gray-300'}`}
                                        >
                                            <div className="flex items-center space-x-1.5">
                                                <img src={user?.photoURL} alt={user?.displayName} className="w-4 h-4 rounded-full" />
                                                <p className="font-semibold truncate flex-1">{user?.displayName}</p>
                                            </div>
                                            <p className="pl-5 text-gray-600 dark:text-gray-400">{shift.start} - {shift.end}</p>
                                             {canInteract && (
                                                <div className="absolute top-0.5 right-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <button onClick={(e) => handleDelete(e, shift.id)} className="p-0.5 rounded-full text-red-500 hover:bg-red-200 dark:hover:bg-red-800" aria-label="Delete shift">
                                                        <TrashIcon className="w-3.5 h-3.5" />
                                                    </button>
                                                </div>
                                            )}
                                        </button>
                                    );
                                })}
                            </div>
                            {userRole === 'management' && (
                               <button onClick={() => onAddShiftClick(dateStr)} className="absolute bottom-1 right-1 p-1 rounded-full text-gray-400 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity hover:bg-indigo-100 hover:text-indigo-600 dark:hover:bg-gray-700 dark:hover:text-indigo-300" aria-label={`Add shift for ${dateStr}`}>
                                   <PlusIcon className="w-4 h-4" />
                               </button>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default Calendar;