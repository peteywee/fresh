import React, { useState } from 'react';
import type { User } from '../types';
import { LogoIcon } from './icons';
import * as firebaseService from '../services/firebaseService';

interface OnboardingProps {
    user: Partial<User>;
    onComplete: () => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ user, onComplete }) => {
    const [orgName, setOrgName] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!orgName.trim()) {
            setError('Organization name cannot be empty.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            await firebaseService.createOrganizationAndUser(user, orgName);
            onComplete();
        } catch (err) {
            const message = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(`Failed to create organization: ${message}`);
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
            <div className="w-full max-w-md mx-auto">
                <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 text-center">
                    <div className="flex items-center justify-center mb-6">
                        <LogoIcon className="h-12 w-12 text-indigo-500" />
                        <span className="text-4xl font-bold text-gray-800 dark:text-white ml-3">Shyft</span>
                    </div>
                    <h1 className="text-2xl font-semibold text-gray-700 dark:text-gray-200">
                        Welcome, {user.displayName}!
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 mt-2 mb-8">
                        Let's get you set up. Create an organization to start managing your team.
                    </p>
                    
                    <form onSubmit={handleSubmit} className="space-y-6 text-left">
                        {error && <p className="text-sm text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg text-center">{error}</p>}
                        <div>
                            <label htmlFor="orgName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Organization Name
                            </label>
                            <input
                                type="text"
                                id="orgName"
                                value={orgName}
                                onChange={(e) => setOrgName(e.target.value)}
                                placeholder="e.g., Downtown Cafe"
                                required
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full flex items-center justify-center px-4 py-3 bg-indigo-600 text-white rounded-lg shadow-sm text-sm font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-wait transition-colors"
                        >
                            {isLoading ? (
                                <>
                                   <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                                   Creating...
                                </>
                            ) : (
                                'Create Organization & Continue'
                            )}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Onboarding;