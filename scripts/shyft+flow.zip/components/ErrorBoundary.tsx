import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallbackMessage?: string;
}

interface State {
  hasError: boolean;
  error?: Error;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
  };

  public static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // You can also log the error to an error reporting service
    console.error("Uncaught error:", error, errorInfo);
  }

  private handleRetry = () => {
    // A simple way to retry is to reload the page.
    window.location.reload();
  };

  // Fix: Changed render to a standard class method to ensure `this` context is correctly bound.
  public render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return (
        <div className="p-8 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded-lg shadow-md border border-red-200 dark:border-red-800 text-center">
            <h2 className="text-xl font-bold mb-2">Oops! Something went wrong.</h2>
            <p className="mb-4">{this.props.fallbackMessage || "We encountered an unexpected error. Please try again."}</p>
            {this.state.error && (
                <pre className="text-xs text-left bg-red-100 dark:bg-red-900/50 p-2 rounded overflow-x-auto mb-4">
                    <code>{this.state.error.toString()}</code>
                </pre>
            )}
            <button
                onClick={this.handleRetry}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
                Try Again
            </button>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
