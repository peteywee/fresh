import React, { useState, useEffect } from 'react';
import type { User, Organization } from '../types';
import { LogoIcon } from './icons';

interface WelcomeProps {
    user: User;
    onComplete: () => void;
    isMock?: boolean;
}

const Welcome: React.FC<WelcomeProps> = ({ user, onComplete, isMock = false }) => {
    const [organization, setOrganization] = useState<Organization | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchOrganizationDetails = async () => {
            if (!isMock && user.orgId) {
                try {
                    const firebaseService = await import('../services/firebaseService');
                    const org = await firebaseService.getOrganization(user.orgId);
                    setOrganization(org);
                } catch (err) {
                    console.error("Failed to fetch organization details:", err);
                    setError("Could not load your organization's details.");
                }
            } else if (isMock) {
                // In mock mode, just use a dummy org name
                setOrganization({ id: user.orgId, name: 'Demo Organization', ownerUid: 'mgmt001' });
            }
        };
        fetchOrganizationDetails();
    }, [user.orgId, isMock]);

    const handleGetStarted = async () => {
        setIsLoading(true);
        setError(null);
        try {
            if (!isMock) {
                const firebaseService = await import('../services/firebaseService');
                await firebaseService.markUserAsOnboarded(user.uid);
            }
            onComplete();
        } catch (err) {
            const message = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(`Failed to update your profile: ${message}`);
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
            <div className="w-full max-w-md mx-auto">
                <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 text-center">
                    <div className="flex items-center justify-center mb-6">
                        <LogoIcon className="h-12 w-12 text-indigo-500" />
                        <span className="text-4xl font-bold text-gray-800 dark:text-white ml-3">Shyft</span>
                    </div>
                    
                    <h1 className="text-2xl font-semibold text-gray-700 dark:text-gray-200">
                        Welcome, {user.displayName}!
                    </h1>
                    
                    {organization ? (
                        <p className="text-gray-500 dark:text-gray-400 mt-2 mb-8">
                            You have been invited to join <span className="font-bold text-gray-600 dark:text-gray-300">{organization.name}</span> as a <span className="font-bold capitalize text-gray-600 dark:text-gray-300">{user.role}</span>.
                        </p>
                    ) : (
                        <div className="h-20 flex items-center justify-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
                        </div>
                    )}
                    
                    {error && <p className="text-sm text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg text-center mb-4">{error}</p>}

                    <button
                        onClick={handleGetStarted}
                        disabled={isLoading || !organization}
                        className="w-full flex items-center justify-center px-4 py-3 bg-indigo-600 text-white rounded-lg shadow-sm text-sm font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-wait transition-colors"
                    >
                        {isLoading ? (
                            <>
                               <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                               Getting things ready...
                            </>
                        ) : (
                            'Get Started'
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Welcome;