
import React, { useState, useCallback } from 'react';
import type { User, Shift } from '../types';
import { CloseIcon, SparklesIcon, CalendarPlusIcon } from './icons';
import { generateSchedule } from '../services/geminiService';

type GeneratedShift = Omit<Shift, 'id' | 'orgId'>;

interface GenerateScheduleModalProps {
    isOpen: boolean;
    onClose: () => void;
    onScheduleGenerated: (shifts: GeneratedShift[]) => void;
    users: User[];
}

const GenerateScheduleModal: React.FC<GenerateScheduleModalProps> = ({ isOpen, onClose, onScheduleGenerated, users }) => {
    const [prompt, setPrompt] = useState('Generate a full week schedule for all staff members starting next Monday, ensuring fair distribution of hours.');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [generatedShifts, setGeneratedShifts] = useState<GeneratedShift[] | null>(null);

    const usersById = React.useMemo(() => new Map(users.map(u => [u.uid, u])), [users]);

    const handleGenerate = useCallback(async () => {
        if (!prompt.trim() || isLoading) return;
        setIsLoading(true);
        setError('');
        setGeneratedShifts(null);
        try {
            const result = await generateSchedule(prompt, users);
            setGeneratedShifts(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [prompt, isLoading, users]);
    
    const handleAddToCalendar = () => {
        if (generatedShifts) {
            onScheduleGenerated(generatedShifts);
            handleClose();
        }
    };

    const handleClose = () => {
        setPrompt('Generate a full week schedule for all staff members starting next Monday, ensuring fair distribution of hours.');
        setIsLoading(false);
        setError('');
        setGeneratedShifts(null);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog" onClick={handleClose}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl transform transition-all" onClick={e => e.stopPropagation()}>
                <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
                    <h3 className="text-xl font-semibold text-gray-800 dark:text-white flex items-center">
                       <CalendarPlusIcon className="w-6 h-6 mr-2 text-indigo-500" />
                       AI Schedule Generator
                    </h3>
                    <button type="button" onClick={handleClose} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close modal">
                        <CloseIcon className="w-5 h-5 text-gray-500 dark:text-gray-400"/>
                    </button>
                </div>

                <div className="p-6 space-y-4">
                    <div>
                        <label htmlFor="schedule-prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Prompt</label>
                        <textarea
                            id="schedule-prompt"
                            rows={3}
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="e.g., Generate a schedule for next week..."
                            className="mt-1 w-full px-4 py-2 text-gray-700 bg-gray-100 dark:bg-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            disabled={isLoading}
                        />
                         <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Describe the schedule you want. Include dates, staff preferences, and shift lengths.</p>
                    </div>
                    
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading || !prompt.trim()}
                        className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed flex items-center justify-center transition-colors duration-200"
                    >
                        {isLoading ? (
                           <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        ) : (
                           <SparklesIcon className="w-5 h-5 mr-2"/>
                        )}
                        {isLoading ? 'Generating...' : 'Generate with AI'}
                    </button>

                    {error && <div className="p-3 text-red-700 bg-red-100 dark:text-red-300 dark:bg-red-900/40 rounded-md text-sm">{error}</div>}

                    {generatedShifts && (
                        <div>
                            <h4 className="font-semibold text-gray-800 dark:text-white mb-2">Suggested Schedule:</h4>
                            <div className="max-h-60 overflow-y-auto bg-gray-50 dark:bg-gray-900/50 p-3 rounded-lg border dark:border-gray-700 space-y-2">
                                {generatedShifts.length > 0 ? generatedShifts.map((shift, i) => (
                                    <div key={i} className="flex items-center justify-between text-sm p-2 bg-white dark:bg-gray-800 rounded-md">
                                        <div className="font-medium text-gray-800 dark:text-gray-200">{usersById.get(shift.userId)?.displayName || 'Unknown User'}</div>
                                        <div className="text-gray-600 dark:text-gray-400">{shift.date}</div>
                                        <div className="text-gray-600 dark:text-gray-400">{shift.start} - {shift.end}</div>
                                    </div>
                                )) : <p className="text-center text-gray-500 dark:text-gray-400">The AI didn't return any shifts for this request.</p>}
                            </div>
                        </div>
                    )}
                </div>

                <div className="flex justify-end items-center p-4 bg-gray-50 dark:bg-gray-800/50 border-t dark:border-gray-700 rounded-b-lg space-x-3">
                    <button type="button" onClick={handleClose} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none">
                        Cancel
                    </button>
                    <button 
                        type="button" 
                        onClick={handleAddToCalendar}
                        disabled={!generatedShifts || generatedShifts.length === 0}
                        className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-green-300 dark:disabled:bg-green-800 disabled:cursor-not-allowed">
                        Add to Calendar
                    </button>
                </div>
            </div>
        </div>
    );
};

export default GenerateScheduleModal;
