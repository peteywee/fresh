import React, { useState, useEffect } from 'react';
import type { User, Shift } from '../types';
import { CloseIcon } from './icons';

interface ShiftModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (shiftData: Omit<Shift, 'id'> | Shift) => void;
    users: User[]; // Staff users
    date: string;
    orgId: string;
    shiftToEdit?: Shift | null;
}

const ShiftModal: React.FC<ShiftModalProps> = ({ isOpen, onClose, onSave, users, date, orgId, shiftToEdit }) => {
    const [userId, setUserId] = useState<string>('');
    const [startTime, setStartTime] = useState('09:00');
    const [endTime, setEndTime] = useState('17:00');
    const [error, setError] = useState('');

    const isEditMode = !!shiftToEdit;

    useEffect(() => {
        if (isOpen) {
            if (isEditMode) {
                setUserId(shiftToEdit.userId);
                setStartTime(shiftToEdit.start);
                setEndTime(shiftToEdit.end);
            } else {
                setUserId(users[0]?.uid || '');
                setStartTime('09:00');
                setEndTime('17:00');
            }
            setError('');
        }
    }, [isOpen, isEditMode, shiftToEdit, users]);

    if (!isOpen) return null;
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!userId || !startTime || !endTime) {
            setError('All fields are required.');
            return;
        }
        if (endTime <= startTime) {
            setError('End time must be after start time.');
            return;
        }

        const commonShiftData = {
            userId,
            orgId,
            date: shiftToEdit?.date || date,
            start: startTime,
            end: endTime,
        };

        if (isEditMode) {
            onSave({ ...commonShiftData, id: shiftToEdit.id });
        } else {
            onSave(commonShiftData);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog" onClick={onClose}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md transform transition-all" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
                        <h3 className="text-xl font-semibold text-gray-800 dark:text-white">{isEditMode ? 'Edit Shift' : 'Add Shift'}</h3>
                        <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close modal">
                            <CloseIcon className="w-5 h-5 text-gray-500 dark:text-gray-400"/>
                        </button>
                    </div>

                    <div className="p-6 space-y-4">
                        {error && <div className="p-3 text-red-700 bg-red-100 dark:text-red-300 dark:bg-red-900/40 rounded-md text-sm">{error}</div>}
                        <div>
                            <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Date</label>
                            <input type="text" id="date" value={shiftToEdit?.date || date} readOnly className="mt-1 block w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none" />
                        </div>
                        <div>
                            <label htmlFor="user" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Staff Member</label>
                            <select id="user" value={userId} onChange={e => setUserId(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                {users.map(user => (
                                    <option key={user.uid} value={user.uid}>{user.displayName}</option>
                                ))}
                            </select>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="start-time" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Start Time</label>
                                <input type="time" id="start-time" value={startTime} onChange={e => setStartTime(e.target.value)} step="900" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500" />
                            </div>
                            <div>
                                <label htmlFor="end-time" className="block text-sm font-medium text-gray-700 dark:text-gray-300">End Time</label>
                                <input type="time" id="end-time" value={endTime} onChange={e => setEndTime(e.target.value)} step="900" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500" />
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end items-center p-4 bg-gray-50 dark:bg-gray-800/50 border-t dark:border-gray-700 rounded-b-lg space-x-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none">
                            Cancel
                        </button>
                        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            {isEditMode ? 'Save Changes' : 'Save Shift'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ShiftModal;