import React, { Suspense } from 'react';
import { isFirebaseConfigured } from './firebaseConfig';
import AppWithMockData from './AppWithMockData';

const FirebaseWarningBanner = () => (
  <div className="bg-yellow-400 dark:bg-yellow-600 text-center p-2 text-sm text-black dark:text-white font-semibold">
    Firebase is not configured. Running in demo mode with mock data. Please see `firebaseConfig.ts`.
  </div>
);

const LoadingSpinner = () => (
    <div className="flex items-center justify-center h-screen bg-gray-100 dark:bg-gray-900">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-500"></div>
    </div>
);

// Lazy load the Firebase-dependent part of the app to prevent module-level errors
// when Firebase is not configured.
const AppWithFirebase = React.lazy(() => import('./AppWithFirebase'));

function App() {
  if (isFirebaseConfigured) {
    return (
      <Suspense fallback={<LoadingSpinner />}>
        <AppWithFirebase />
      </Suspense>
    );
  }
  
  return (
    <>
      <FirebaseWarningBanner />
      <AppWithMockData />
    </>
  );
}

export default App;
